package pl.postownik.app

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("postownik", MODE_PRIVATE) }
    private lateinit var timer: TextView
    private lateinit var mode: TextView
    private lateinit var progress: ProgressBar
    private val handler = android.os.Handler()
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotificationPermission()
        buildUi()
        scheduleReminders()
        handler.post(tick)
    }

    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }

    private fun buildUi() {
        val bg = Color.rgb(16, 21, 18)
        val panel = Color.rgb(28, 36, 31)
        val green = Color.rgb(117, 214, 162)
        val white = Color.WHITE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("POSTOWNIK", 26, green, true))
        content.addView(label("Twój rytm postu przerywanego", 14, 0xFFB8C4BC.toInt(), false))
        content.addView(space(24))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            setBackgroundColor(panel)
        }
        mode = label("OKNO POSTU", 18, green, true)
        timer = label("--:--:--", 42, white, true)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFF46534B.toInt())
        }
        card.addView(mode); card.addView(space(10)); card.addView(timer)
        card.addView(label("pozostały czas", 13, 0xFFB8C4BC.toInt(), false))
        card.addView(space(18)); card.addView(progress, LinearLayout.LayoutParams(-1, 12))
        content.addView(card)
        content.addView(space(24))
        content.addView(label("USTAWIENIA", 14, green, true))
        content.addView(space(8))

        val fasting = NumberPicker(this).apply { minValue = 1; maxValue = 23; value = prefs.getInt("fast", 16); wrapSelectorWheel = false }
        val startHour = NumberPicker(this).apply { minValue = 0; maxValue = 23; value = prefs.getInt("hour", 20); wrapSelectorWheel = true; setFormatter { String.format("%02d", it) } }
        val startMinute = NumberPicker(this).apply { minValue = 0; maxValue = 59; value = prefs.getInt("minute", 0); wrapSelectorWheel = true; setFormatter { String.format("%02d", it) } }
        content.addView(label("Długość postu (godziny)", 14, white, false))
        content.addView(fasting)
        content.addView(space(8))
        content.addView(label("Godzina rozpoczęcia postu", 14, white, false))
        val timeRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        timeRow.addView(startHour); timeRow.addView(label(":", 22, white, true)); timeRow.addView(startMinute)
        content.addView(timeRow)
        val save = Button(this).apply {
            text = "ZAPISZ I URUCHOM"
            setTextColor(Color.rgb(16, 21, 18))
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener {
                prefs.edit().putInt("fast", fasting.value).putInt("hour", startHour.value).putInt("minute", startMinute.value).apply()
                scheduleReminders()
                refresh()
                Toast.makeText(this@MainActivity, "Harmonogram zapisany", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(space(18)); content.addView(save)
        content.addView(space(16))
        content.addView(label("Okno żywieniowe to pozostała część doby. Godziny wyliczane są automatycznie.", 13, 0xFFB8C4BC.toInt(), false))
        content.addView(space(12))
        content.addView(label("Powiadomienia: początek postu i koniec postu. Harmonogram odnawia się codziennie.", 12, 0xFF89968E.toInt(), false))
        setContentView(root)
    }

    private fun refresh() {
        val fast = prefs.getInt("fast", 16)
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.getInt("hour", 20))
            set(Calendar.MINUTE, prefs.getInt("minute", 0))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val now = Calendar.getInstance()
        val end = (start.clone() as Calendar).apply { add(Calendar.HOUR_OF_DAY, fast) }
        val nextStart = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val inFast = now.timeInMillis >= start.timeInMillis && now.timeInMillis < end.timeInMillis ||
            now.timeInMillis < start.timeInMillis && now.timeInMillis >= (start.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1); add(Calendar.HOUR_OF_DAY, fast) }.timeInMillis
        val target = if (inFast) {
            if (now.timeInMillis < start.timeInMillis) (start.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1); add(Calendar.HOUR_OF_DAY, fast) } else end
        } else if (now.timeInMillis < start.timeInMillis) start else nextStart
        val remain = (target.timeInMillis - now.timeInMillis).coerceAtLeast(0) / 1000
        val h = remain / 3600; val m = (remain % 3600) / 60; val s = remain % 60
        mode.text = if (inFast) "OKNO POSTU" else "OKNO ŻYWIENIOWE"
        mode.setTextColor(if (inFast) 0xFF75D6A2.toInt() else 0xFFFFC56D.toInt())
        timer.text = String.format("%02d:%02d:%02d", h, m, s)
        val total = if (inFast) fast * 3600L else (24 - fast) * 3600L
        progress.progress = (((total - remain).coerceAtLeast(0) * 1000) / total).toInt()
    }

    private fun scheduleReminders() {
        val fast = prefs.getInt("fast", 16)
        val hour = prefs.getInt("hour", 20)
        val minute = prefs.getInt("minute", 0)
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val end = (start.clone() as Calendar).apply { add(Calendar.HOUR_OF_DAY, fast) }
        setAlarm(100, start.timeInMillis, "Czas rozpocząć post", "Zaczyna się Twoje okno postu.")
        setAlarm(101, end.timeInMillis, "Post zakończony", "Zaczyna się Twoje okno żywieniowe.")
    }

    private fun setAlarm(id: Int, time: Long, title: String, body: String) {
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("title", title); putExtra("body", body); putExtra("id", id)
        }
        val pi = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
        } else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("postownik_reminders", "Przypomnienia Postownika", NotificationManager.IMPORTANCE_HIGH)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
    }

    private fun label(t: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = size.toFloat(); setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(4, 4, 4, 4)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Postownik"
        val body = intent.getStringExtra("body") ?: ""
        val id = intent.getIntExtra("id", 1)
        val notification = NotificationCompat.Builder(context, "postownik_reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT < 33 || ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            NotificationManagerCompat.from(context).notify(id, notification)
        val prefs = context.getSharedPreferences("postownik", Context.MODE_PRIVATE)
        val fast = prefs.getInt("fast", 16)
        val nextTime = System.currentTimeMillis() + if (id == 100) fast * 3600_000L else (24 - fast) * 3600_000L
        val nextId = if (id == 100) 101 else 100
        val nextTitle = if (nextId == 100) "Czas rozpocząć post" else "Post zakończony"
        val nextBody = if (nextId == 100) "Zaczyna się Twoje okno postu." else "Zaczyna się Twoje okno żywieniowe."
        val nextIntent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", nextTitle); putExtra("body", nextBody); putExtra("id", nextId)
        }
        val pi = PendingIntent.getBroadcast(context, nextId, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTime, pi)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
        }
    }
}
