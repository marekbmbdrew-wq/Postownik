# Postownik (Android)

Prosta aplikacja Android do postu przerywanego.

## Funkcje
- Ustawienie długości postu w godzinach (1–23).
- Ustawienie codziennej godziny rozpoczęcia postu.
- Automatyczne wyliczanie okna żywieniowego jako pozostałej części doby.
- Odliczanie do końca aktualnego okna.
- Powiadomienia o początku postu i rozpoczęciu okna żywieniowego.
- Ciemny interfejs.

## Budowanie APK
1. Otwórz folder projektu w Android Studio (Ladybug lub nowsze).
2. Poczekaj na synchronizację Gradle.
3. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

## Ważne
- Przy pierwszym uruchomieniu zezwól na powiadomienia.
- Android 12+ może poprosić o zgodę na dokładne alarmy. Włącz ją, aby przypomnienia trafiały o zaplanowanej godzinie.
- Niektóre nakładki producentów ograniczają działanie aplikacji w tle. W razie opóźnień wyłącz dla Postownika optymalizację baterii.
- To jest wersja 1.0: harmonogram jest codzienny i oparty na stałej godzinie rozpoczęcia postu.
- Aplikacja nie ocenia bezpieczeństwa wybranego czasu postu. Przy chorobach, ciąży, karmieniu piersią, zaburzeniach odżywiania lub lekach wymagających posiłku dobór postu skonsultuj z lekarzem.


## Automatyczne przygotowanie pliku instalacyjnego APK

W projekcie znajduje się workflow GitHub Actions (`.github/workflows/build-apk.yml`).
1. Utwórz repozytorium na GitHubie i wgraj do niego zawartość tego folderu.
2. Otwórz zakładkę **Actions** w repozytorium.
3. Wybierz **Build Postownik APK**, a następnie **Run workflow**.
4. Po zakończeniu zadania otwórz jego wynik i pobierz artefakt **Postownik-APK**.
5. Wypakuj artefakt. Plik `app-debug.apk` można przenieść na telefon i zainstalować.

To jest kompilacja debug do prywatnego testowania. Do publikacji w Google Play należy przygotować podpisany build release.
