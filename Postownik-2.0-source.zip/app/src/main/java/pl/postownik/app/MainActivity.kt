package pl.postownik.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private const val PREFS = "postownik"
private const val HISTORY = "history"
private const val CHANNEL = "postownik_reminders"
private val GREEN = Color.rgb(117, 214, 162)
private val BG = Color.rgb(16, 21, 18)
private val PANEL = Color.rgb(28, 36, 31)
private val MUTED = Color.rgb(184, 196, 188)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private lateinit var phase: TextView
    private lateinit var countdown: TextView
    private lateinit var ring: ProgressBar
    private lateinit var details: TextView
    private lateinit var stats: TextView
    private lateinit var historyView: TextView
    private lateinit var fastPicker: Spinner
    private val handler = android.os.Handler()
    private val tick = object : Runnable {
        override fun run() { refreshDashboard(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        askPermissions()
        buildScreen()
        ReminderScheduler.scheduleNext(this)
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
            setBackgroundColor(BG)
        }
        scroll.addView(page)
        page.addView(text("POSTOWNIK", 27, GREEN, true))
        page.addView(text("Post przerywany. Twój plan, Twoje tempo.", 14, MUTED))
        page.addView(space(20))

        val dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 22, 18, 22)
            background = rounded(PANEL, 24)
        }
        phase = text("OKNO POSTU", 18, GREEN, true)
        countdown = text("--:--:--", 42, Color.WHITE, true)
        ring = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(GREEN)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFF46534B.toInt())
        }
        details = text("", 13, MUTED)
        dashboard.addView(phase)
        dashboard.addView(space(8))
        dashboard.addView(countdown)
        dashboard.addView(text("pozostały czas", 12, MUTED))
        dashboard.addView(space(16))
        dashboard.addView(ring, LinearLayout.LayoutParams(-1, 12))
        dashboard.addView(space(12))
        dashboard.addView(details)
        page.addView(dashboard)
        page.addView(space(18))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val endBtn = button("Zakończ post", false) { finishFast(true) }
        val startBtn = button("Rozpocznij post", true) { startFastNow() }
        actions.addView(startBtn, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(spaceW(8))
        actions.addView(endBtn, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(actions)
        page.addView(space(22))

        page.addView(section("PLAN POSTU"))
        page.addView(text("Wybierz schemat", 14, Color.WHITE))
        val schemas = listOf("12:12", "14:10", "16:8", "18:6", "20:4", "Własny")
        fastPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, schemas)
            val current = prefs.getInt("fastHours", 16)
            setSelection(schemas.indexOf("${current}:${24-current}").takeIf { it >= 0 } ?: 2)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    val selected = schemas[position]
                    if (selected != "Własny") {
                        val hours = selected.substringBefore(":").toInt()
                        prefs.edit().putInt("fastHours", hours).apply()
                        ReminderScheduler.scheduleNext(this@MainActivity)
                        refreshDashboard()
                    } else showCustomHours()
                }
            }
        }
        page.addView(fastPicker)
        page.addView(space(12))

        val scheduleBtn = button("Ustaw godzinę codziennego postu", false) { chooseStartTime() }
        page.addView(scheduleBtn)
        page.addView(space(8))
        page.addView(button("Pomiń dzisiejszy post", false) { skipToday() })
        page.addView(space(22))

        page.addView(section("STATYSTYKI"))
        stats = text("", 14, Color.WHITE)
        page.addView(stats)
        page.addView(space(18))
        page.addView(section("HISTORIA OSTATNICH POSTÓW"))
        historyView = text("", 13, MUTED)
        page.addView(historyView)
        page.addView(space(14))
        page.addView(text("Przypomnienia wymagają zgody na powiadomienia i dokładne alarmy. Zmiany harmonogramu zapisują się na tym urządzeniu.", 12, MUTED))
        setContentView(scroll)
    }

    private fun refreshDashboard() {
        val fast = prefs.getInt("fastHours", 16).coerceIn(1, 23)
        val now = System.currentTimeMillis()
        val manualStart = prefs.getLong("manualStart", 0L)
        val manualEnd = prefs.getLong("manualEnd", 0L)
        val activeManual = manualStart > manualEnd && manualStart > 0L
        val start = if (activeManual) manualStart else scheduledStart(now)
        val end = if (activeManual) 0L else start + fast * 3600_000L
        val isFasting = if (activeManual) true else now >= start && now < end
        val target = if (activeManual) manualEnd.takeIf { it > now } ?: (now + 3600_000L)
                    else if (isFasting) end else if (now < start) start else start + 24*3600_000L
        val remain = ((target - now).coerceAtLeast(0L) / 1000L)
        countdown.text = String.format(Locale.getDefault(), "%02d:%02d:%02d", remain/3600, (remain%3600)/60, remain%60)
        phase.text = if (isFasting) "OKNO POSTU" else "OKNO ŻYWIENIOWE"
        phase.setTextColor(if (isFasting) GREEN else 0xFFFFC56D.toInt())
        val cycleStart = if (isFasting) start else start + fast*3600_000L
        val total = if (isFasting) fast*3600_000L else (24-fast)*3600_000L
        val elapsed = (now-cycleStart).coerceIn(0L,total)
        ring.progress = ((elapsed*1000L)/total).toInt()
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        val foodStart = fmt.format(Date(start + fast*3600_000L))
        val fastStart = fmt.format(Date(start))
        details.text = "Post: $fastStart–$foodStart  •  Jedzenie: $foodStart–$fastStart"
        updateStats()
    }

    private fun scheduledStart(now: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, prefs.getInt("startHour", 20))
            set(Calendar.MINUTE, prefs.getInt("startMinute", 0))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStart = c.timeInMillis
        return if (now >= todayStart) todayStart else todayStart - 24 * 3600_000L
    }

    private fun startFastNow() {
        val now = System.currentTimeMillis()
        prefs.edit().putLong("manualStart", now).putLong("manualEnd", 0L).apply()
        ReminderScheduler.cancel(this)
        val finish = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("title", "Post zakończony")
            putExtra("body", "Minął zaplanowany czas postu. Zaczyna się okno żywieniowe.")
        }
        val pi = PendingIntent.getBroadcast(this, 101, finish, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val duration = prefs.getInt("fastHours",16) * 3600_000L
        ReminderScheduler.setExact(this, am, now+duration, pi)
        refreshDashboard()
        Toast.makeText(this, "Post rozpoczęty", Toast.LENGTH_SHORT).show()
    }

    private fun finishFast(completed: Boolean) {
        val start = prefs.getLong("manualStart", 0L)
        val now = System.currentTimeMillis()
        if (start > 0L) addHistory(start, now, completed)
        prefs.edit().putLong("manualStart", 0L).putLong("manualEnd", 0L).apply()
        ReminderScheduler.scheduleNext(this)
        refreshDashboard()
        Toast.makeText(this, if (completed) "Post zakończony i zapisany" else "Post przerwany i zapisany", Toast.LENGTH_SHORT).show()
    }

    private fun skipToday() {
        val now = System.currentTimeMillis()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.getInt("startHour", 20))
            set(Calendar.MINUTE, prefs.getInt("startMinute", 0))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
            add(Calendar.DAY_OF_YEAR, 1)
        }
        prefs.edit().putLong("skipStartAt", next.timeInMillis).apply()
        ReminderScheduler.scheduleNext(this)
        Toast.makeText(this, "Najbliższy zaplanowany post pominięty.", Toast.LENGTH_SHORT).show()
        refreshDashboard()
    }

    private fun chooseStartTime() {
        val hour = prefs.getInt("startHour",20)
        val minute = prefs.getInt("startMinute",0)
        TimePickerDialog(this, { _, h, m ->
            prefs.edit().putInt("startHour",h).putInt("startMinute",m).apply()
            ReminderScheduler.scheduleNext(this)
            refreshDashboard()
        }, hour, minute, true).show()
    }

    private fun showCustomHours() {
        val picker = NumberPicker(this).apply { minValue=1; maxValue=23; value=prefs.getInt("fastHours",16) }
        AlertDialog.Builder(this).setTitle("Długość postu (godziny)").setView(picker)
            .setNegativeButton("Anuluj", null)
            .setPositiveButton("Zapisz") { _, _ ->
                prefs.edit().putInt("fastHours",picker.value).apply()
                ReminderScheduler.scheduleNext(this); refreshDashboard()
            }.show()
    }

    private fun updateStats() {
        val arr = readHistory()
        val now = System.currentTimeMillis()
        fun summary(days: Int): Pair<Int, Int> {
            var count=0; var minutes=0
            for (i in 0 until arr.length()) {
                val o=arr.optJSONObject(i) ?: continue
                if (now-o.optLong("end") <= days*86400_000L && o.optBoolean("completed")) {
                    count++; minutes += ((o.optLong("end")-o.optLong("start"))/60000L).toInt()
                }
            }
            return count to minutes
        }
        val w=summary(7); val m=summary(30)
        stats.text = "Ostatnie 7 dni: ${w.first} zakończonych postów, ${w.second/60} godz. ${w.second%60} min.\n" +
                     "Ostatnie 30 dni: ${m.first} zakończonych postów, ${m.second/60} godz. ${m.second%60} min."
        val lines = mutableListOf<String>()
        for (i in (arr.length()-1 downTo 0).take(8)) {
            val o=arr.optJSONObject(i) ?: continue
            val date=SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(o.optLong("start")))
            val mins=((o.optLong("end")-o.optLong("start"))/60000).coerceAtLeast(0)
            lines.add("$date  •  ${mins/60} h ${mins%60} min  •  ${if(o.optBoolean("completed")) "zakończony" else "przerwany"}")
        }
        historyView.text = if (lines.isEmpty()) "Brak zapisanych postów. Zakończony lub przerwany post pojawi się tutaj." else lines.joinToString("\n")
    }

    private fun addHistory(start: Long, end: Long, completed: Boolean) {
        val arr=readHistory()
        arr.put(JSONObject().put("start",start).put("end",end).put("completed",completed))
        prefs.edit().putString(HISTORY,arr.toString()).apply()
    }
    private fun readHistory() = try { JSONArray(prefs.getString(HISTORY,"[]")) } catch (_: Exception) { JSONArray() }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),7)
        if (Build.VERSION.SDK_INT >= 31) {
            val am=getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            val ch=NotificationChannel(CHANNEL,"Przypomnienia Postownika",NotificationManager.IMPORTANCE_HIGH)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun section(s:String)=text(s,14,GREEN,true).apply { setPadding(0,0,0,8) }
    private fun text(s:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); gravity=Gravity.CENTER
        if(bold) setTypeface(typeface,android.graphics.Typeface.BOLD)
        setPadding(4,4,4,4)
    }
    private fun space(h:Int)=android.view.View(this).apply { layoutParams=LinearLayout.LayoutParams(1,h) }
    private fun spaceW(w:Int)=android.view.View(this).apply { layoutParams=LinearLayout.LayoutParams(w,1) }
    private fun button(label:String,primary:Boolean,onClick:()->Unit)=Button(this).apply {
        text=label; setTextColor(if(primary) BG else Color.WHITE)
        backgroundTintList=android.content.res.ColorStateList.valueOf(if(primary) GREEN else PANEL)
        setOnClickListener { onClick() }
    }
    private fun rounded(color:Int,radius:Int)=android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius=radius.toFloat()
    }
}

object ReminderScheduler {
    fun cancel(context:Context) {
        val i=Intent(context,ReminderReceiver::class.java)
        val pi=PendingIntent.getBroadcast(context,100,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
    fun setExact(context:Context,am:AlarmManager,time:Long,pi:PendingIntent) {
        if(Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pi)
    }
    fun scheduleNext(context:Context) {
        val p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val now=System.currentTimeMillis()
        val hour=p.getInt("startHour",20); val minute=p.getInt("startMinute",0)
        val fast=p.getInt("fastHours",16)
        val c=Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,hour); set(Calendar.MINUTE,minute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            if(timeInMillis<=now) add(Calendar.DAY_OF_YEAR,1)
        }
        var start=c.timeInMillis
        val skipAt = p.getLong("skipStartAt", 0L)
        if (skipAt > 0L && start <= skipAt) {
            start = skipAt + 24 * 3600_000L
            p.edit().remove("skipStartAt").apply()
        }
        val end=start+fast*3600_000L
        val startIntent=Intent(context,ReminderReceiver::class.java).apply {
            putExtra("title","Czas rozpocząć post"); putExtra("body","Zaczyna się Twoje okno postu.")
        }
        val endIntent=Intent(context,ReminderReceiver::class.java).apply {
            putExtra("title","Post zakończony"); putExtra("body","Zaczyna się Twoje okno żywieniowe.")
        }
        val startPi=PendingIntent.getBroadcast(context,100,startIntent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val endPi=PendingIntent.getBroadcast(context,101,endIntent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        setExact(context,am,start,startPi); setExact(context,am,end,endPi)
    }
}

class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val title=intent.getStringExtra("title") ?: "Postownik"
        val body=intent.getStringExtra("body") ?: ""
        val n=NotificationCompat.Builder(context,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
        if(Build.VERSION.SDK_INT<33 || ActivityCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
            NotificationManagerCompat.from(context).notify((System.currentTimeMillis()%100000).toInt(),n)
        ReminderScheduler.scheduleNext(context)
    }
}

class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        if(intent.action==Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.scheduleNext(context)
    }
}
