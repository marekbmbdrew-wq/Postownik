# Postownik 2.0

Androidowy timer postu przerywanego w ciemnym motywie. Zachowuje identyfikator aplikacji `pl.postownik.app`, więc może być instalowany jako aktualizacja poprzedniej wersji.

## Funkcje
- Schematy 12:12, 14:10, 16:8, 18:6, 20:4 oraz własna długość postu.
- Codzienna godzina rozpoczęcia postu.
- Odliczanie do zmiany fazy i pasek postępu.
- Ręczne rozpoczęcie postu i zakończenie/przerwanie postu.
- Pominięcie kolejnego dnia w harmonogramie.
- Historia zakończonych i przerwanych postów.
- Statystyki z ostatnich 7 i 30 dni.
- Powiadomienia o początku postu i okna żywieniowego.

## Budowanie
Projekt jest budowany przez GitHub Actions. W repozytorium należy umieścić plik `Postownik-2.0-source.zip` oraz workflow `.github/workflows/build-apk.yml` dostarczony osobno. Workflow publikuje artefakt `Postownik-APK`.

## Aktualizacja
Pakiet ma tę samą nazwę `pl.postownik.app`, a versionCode został podniesiony do 2. Zainstaluj nowy APK bez odinstalowywania starej wersji. Dane aplikacji powinny pozostać na urządzeniu.
